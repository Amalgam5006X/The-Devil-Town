tag @s add terraformingsheep
execute at @s run kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:moss_block"}}]
data merge entity @s {Color:5b,CustomName:'{"text":"Terraforming Sheep","color":"#00FF1A","bold":true}'}
effect give @s glowing 2 1