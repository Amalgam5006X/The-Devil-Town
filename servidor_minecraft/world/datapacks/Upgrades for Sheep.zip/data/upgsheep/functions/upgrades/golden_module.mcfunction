tag @s add goldensheep
execute at @s run kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:gold_block"}}]
data merge entity @s {Color:4b,CustomName:'{"text":"Golden Sheep","color":"gold","bold":true}'}
effect give @s glowing 2 1