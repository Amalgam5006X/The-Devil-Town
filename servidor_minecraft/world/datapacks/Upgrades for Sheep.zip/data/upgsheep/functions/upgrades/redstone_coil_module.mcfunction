tag @s add redstonesheep
execute at @s run kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:redstone_block"}}]
data merge entity @s {Color:14b,CustomName:'{"text":"Redstone Coil Sheep","color":"dark_red","bold":true}'}
effect give @s glowing 2 1