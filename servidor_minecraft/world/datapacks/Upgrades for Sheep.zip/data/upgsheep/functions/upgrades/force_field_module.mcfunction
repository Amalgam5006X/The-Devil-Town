tag @s add forcesheep
execute at @s run kill @e[type=item,distance=..1,nbt={Item:{id:"minecraft:beacon"}}]
data merge entity @s {Color:11b,CustomName:'{"text":"Force Field Sheep","color":"dark_blue","bold":true}'}
effect give @s glowing 2 1