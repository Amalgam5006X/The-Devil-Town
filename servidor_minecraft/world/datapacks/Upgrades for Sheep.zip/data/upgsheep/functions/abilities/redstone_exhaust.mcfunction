particle smoke ~ ~ ~ 1 1 1 1 100 normal
playsound block.anvil.destroy master @a ~ ~ ~
data merge entity @s {Color:0b,Tags:[],CustomName:""}