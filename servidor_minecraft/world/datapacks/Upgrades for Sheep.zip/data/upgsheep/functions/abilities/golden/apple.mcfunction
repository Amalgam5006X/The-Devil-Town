scoreboard players set @s appless 0
execute as @s at @s if entity @e[type=sheep,tag=goldensheep,distance=..8] run function upgsheep:abilities/golden/apple_effect