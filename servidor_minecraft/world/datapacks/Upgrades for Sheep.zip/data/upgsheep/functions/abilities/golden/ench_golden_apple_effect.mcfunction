effect give @s absorption 720 4
effect give @s regeneration 45 2
effect give @s resistance 300 1
effect give @s fire_resistance 480 0
