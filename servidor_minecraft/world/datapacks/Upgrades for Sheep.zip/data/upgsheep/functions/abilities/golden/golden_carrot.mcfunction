scoreboard players set @s golden_carrotss 0
execute as @s at @s if entity @e[type=sheep,tag=goldensheep,distance=..8] run function upgsheep:abilities/golden/golden_carrot_effect