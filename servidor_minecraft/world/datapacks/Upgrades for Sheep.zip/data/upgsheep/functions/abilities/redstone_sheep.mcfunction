execute at @s positioned ~ ~ ~ if block ~ ~-1 ~ #upgsheep:suitable_for_redstone if block ~ ~ ~ air run function upgsheep:abilities/redstone_ffff
execute at @s positioned ~ ~ ~ if block ~ ~-1 ~ #upgsheep:suitable_for_redstone if block ~ ~ ~ iron_trapdoor[facing=east] run setblock ~ ~ ~ repeater[facing=east]
execute at @s positioned ~ ~ ~ if block ~ ~-1 ~ #upgsheep:suitable_for_redstone if block ~ ~ ~ iron_trapdoor[facing=west] run setblock ~ ~ ~ repeater[facing=west]
execute at @s positioned ~ ~ ~ if block ~ ~-1 ~ #upgsheep:suitable_for_redstone if block ~ ~ ~ iron_trapdoor[facing=north] run setblock ~ ~ ~ repeater[facing=north]
execute at @s positioned ~ ~ ~ if block ~ ~-1 ~ #upgsheep:suitable_for_redstone if block ~ ~ ~ iron_trapdoor[facing=south] run setblock ~ ~ ~ repeater[facing=south]
effect give @s slowness 3 255