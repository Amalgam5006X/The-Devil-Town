execute at @s run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 grass_block replace mycelium
execute at @s run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 farmland[moisture=7] replace coarse_dirt
execute at @s run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 oak_sapling replace dead_bush
execute at @s run fill ~-5 ~-5 ~-5 ~5 ~5 ~5 spore_blossom replace hanging_roots