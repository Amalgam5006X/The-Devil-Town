effect give @s absorption 110 3
effect give @s regeneration 18 1
effect give @s resistance 240 0
effect give @s fire_resistance 240 0