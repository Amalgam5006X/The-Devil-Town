particle dust 1 0.91 0.114 1.0 ~6 ~0.5 ~ 0.01 2.5 3 0 60 normal @a[scores={seeFieldParticles=0}]
particle dust 1 0.91 0.114 1.0 ~-6 ~0.5 ~ 0.01 2.5 3 0 60 normal @a[scores={seeFieldParticles=0}]
#Z
particle dust 1 0.91 0.114 1.0 ~ ~0.5 ~6 3 2.5 0.01 0 60 normal @a[scores={seeFieldParticles=0}]
particle dust 1 0.91 0.114 1.0 ~ ~0.5 ~-6 3 2.5 0.01 0 60 normal @a[scores={seeFieldParticles=0}]
#Y
particle dust 1 0.91 0.114 1.0 ~ ~6 ~ 3 0.01 3 0 60 normal @a[scores={seeFieldParticles=0}]
particle dust 1 0.91 0.114 1.0 ~ ~-6 ~ 3 0.01 3 0 60 normal @a[scores={seeFieldParticles=0}]