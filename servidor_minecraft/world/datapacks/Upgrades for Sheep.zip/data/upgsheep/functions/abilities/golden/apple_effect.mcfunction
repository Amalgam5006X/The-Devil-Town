effect give @s absorption 110 0
effect give @s regeneration 6 0