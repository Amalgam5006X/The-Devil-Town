scoreboard players set @s ench_golden_appless 0
execute as @s at @s if entity @e[type=sheep,tag=goldensheep,distance=..8] run function upgsheep:abilities/golden/ench_golden_apple_effect