advancement revoke @s only upgsheep:carrot
execute as @s at @s if entity @e[type=sheep,tag=goldensheep,distance=..8] run function upgsheep:abilities/golden/carrot_effect