#X
particle dust 0.0 0.0 1.0 1.0 ~6 ~0.5 ~ 0.01 2.5 3 0 30 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~-6 ~0.5 ~ 0.01 2.5 3 0 30 normal @a[scores={seeFieldParticles=0}]
#Z
particle dust 0.0 0.0 1.0 1.0 ~ ~0.5 ~6 3 2.5 0.01 0 30 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~ ~0.5 ~-6 3 2.5 0.01 0 30 normal @a[scores={seeFieldParticles=0}]
#Y
particle dust 0.0 0.0 1.0 1.0 ~ ~6 ~ 3 0.01 3 0 30 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~ ~-6 ~ 3 0.01 3 0 30 normal @a[scores={seeFieldParticles=0}]
# Corners
particle dust 0.0 0.0 1.0 1.0 ~6 ~6 ~6 0 0 0 0 1 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~-6 ~6 ~6 0 0 0 0 1 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~6 ~6 ~-6 0 0 0 0 1 normal @a[scores={seeFieldParticles=0}]
particle dust 0.0 0.0 1.0 1.0 ~-6 ~6 ~-6 0 0 0 0 1 normal @a[scores={seeFieldParticles=0}]

#first layer
execute positioned ~6 ~-2 ~6 as @e[dx=-10,dy=8,dz=0,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.0,0.5]}
execute positioned ~6 ~-2 ~-6 as @e[dx=-10,dy=8,dz=0,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.0,-0.5]}
execute positioned ~6 ~6 ~6 as @e[dx=-10,dy=0,dz=-10,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.5,0.0]}
execute positioned ~6 ~-2 ~6 as @e[dx=-10,dy=0,dz=-10,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,-0.5,0.0]}
execute positioned ~6 ~-2 ~6 as @e[dx=0,dy=8,dz=-10,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.5,0.0,0.0]}
execute positioned ~-6 ~-2 ~6 as @e[dx=0,dy=8,dz=-10,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[-0.5,0.0,0.0]}
#second layer
execute positioned ~5 ~-2 ~5 as @e[dx=-9,dy=7,dz=0,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.0,0.5]}
execute positioned ~5 ~-2 ~-5 as @e[dx=-9,dy=7,dz=0,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.0,-0.5]}
execute positioned ~5 ~6 ~5 as @e[dx=-9,dy=0,dz=-9,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,0.5,0.0]}
execute positioned ~5 ~-2 ~5 as @e[dx=-9,dy=0,dz=-9,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.0,-0.5,0.0]}
execute positioned ~5 ~-2 ~5 as @e[dx=0,dy=7,dz=-9,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[0.5,0.0,0.0]}
execute positioned ~-5 ~-2 ~5 as @e[dx=0,dy=7,dz=-9,type=#upgsheep:pushed_by_force_field] run data merge entity @s {Motion:[-0.5,0.0,0.0]}

#Notable hostile mobs that are unaffected: Endermen, Endermites, Shulkers (Shulker cant be pushed whatsoever), Wardens, Slimes and Vexes.