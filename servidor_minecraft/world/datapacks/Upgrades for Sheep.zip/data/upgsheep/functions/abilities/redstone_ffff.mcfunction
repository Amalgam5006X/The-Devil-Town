setblock ~ ~ ~ redstone_wire
execute if predicate upgsheep:explode_chance run function upgsheep:abilities/redstone_exhaust
