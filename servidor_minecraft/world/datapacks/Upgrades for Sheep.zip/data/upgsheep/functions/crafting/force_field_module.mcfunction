
advancement revoke @s only upgsheep:force_field_module
clear @s knowledge_book
give @s beacon{display:{Name:'{"text":"Force Field Module","color":"dark_blue","bold":true,"italic":false}',Lore:['{"text":"Makes a sheep into a walking force field.","color":"light_purple","italic":true}','{"text":"Doesn\'t protect from projectiles.","color":"light_purple","italic":true}']},CustomModelData:100795,Custom:force_field_module,Enchantments:[{}]} 1