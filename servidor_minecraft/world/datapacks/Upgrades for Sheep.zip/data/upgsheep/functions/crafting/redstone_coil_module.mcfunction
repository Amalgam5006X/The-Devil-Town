
advancement revoke @s only upgsheep:golden_module
clear @s knowledge_book
give @s redstone_block{display:{Name:'{"text":"Redstone Coil Module","color":"dark_red","bold":true,"italic":false}',Lore:['{"text":"Will make the sheep lay redstone dust under itself.","color":"light_purple","italic":true}','{"text":"The sheep will not be able to walk by itself, to allow for full control by the user.","color":"light_purple","italic":true}','{"text":"Can be moved by leads/nudging.","color":"light_purple","italic":true}','{"text":"Can convert iron trapdoors into repeaters (direction from the trapdoor).","color":"light_purple","italic":true}']},CustomModelData:100798,Custom:redstone_coil_module,Enchantments:[{}]} 1
