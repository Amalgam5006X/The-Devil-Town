
advancement revoke @s only upgsheep:terraforming_module
clear @s knowledge_book
give @s moss_block{display:{Name:'{"text":"Terraforming Module","color":"dark_green","bold":true,"italic":false}',Lore:['{"text":"Makes a sheep convert all mycelium into grass.","color":"light_purple","italic":true}','{"text":"Some other blocks change into something too.","color":"light_purple","italic":true}']},CustomModelData:100796,Custom:terraforming_module,Enchantments:[{}]} 1