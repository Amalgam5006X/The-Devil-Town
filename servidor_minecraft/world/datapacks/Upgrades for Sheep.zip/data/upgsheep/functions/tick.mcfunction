execute as @e[type=sheep,tag=forcesheep,nbt={Color:11b}] at @s run function upgsheep:abilities/force_field_sheep
execute as @e[type=sheep,tag=redstonesheep,nbt={Color:14b}] at @s run function upgsheep:abilities/redstone_sheep
scoreboard players enable @a seeFieldParticles
execute as @a if score @s seeFieldParticles matches 1.. run function upgsheep:toggleparticles