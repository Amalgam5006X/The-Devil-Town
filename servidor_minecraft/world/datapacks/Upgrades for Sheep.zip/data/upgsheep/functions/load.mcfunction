function upgsheep:1s
function upgsheep:1d
scoreboard objectives add seeFieldParticles trigger
scoreboard players set #aa appless 1
scoreboard objectives add appless used:apple
scoreboard objectives add golden_appless used:golden_apple
scoreboard objectives add ench_golden_appless used:enchanted_golden_apple
scoreboard objectives add golden_carrotss used:golden_carrot
scoreboard objectives add melonss used:melon_slice