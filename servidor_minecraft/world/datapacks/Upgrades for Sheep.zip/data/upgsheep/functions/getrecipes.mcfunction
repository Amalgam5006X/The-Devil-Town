recipe give @s upgsheep:force_field_module
recipe give @s upgsheep:golden_module
recipe give @s upgsheep:redstone_coil_module
recipe give @s upgsheep:terraforming_module
