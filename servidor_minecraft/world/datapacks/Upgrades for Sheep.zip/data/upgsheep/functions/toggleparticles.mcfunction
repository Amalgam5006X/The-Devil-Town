execute if entity @s[scores={seeFieldParticles=2..}] run scoreboard players set @s seeFieldParticles 0
