schedule function upgsheep:1s 1s
execute as @e[type=sheep,tag=!forcesheep,tag=!terraformingsheep,tag=!goldensheep,tag=!redstonesheep] at @s if entity @e[type=item,distance=..1,nbt={Item:{id:"minecraft:beacon",tag:{Custom:force_field_module}}}] run function upgsheep:upgrades/force_field_module
execute as @e[type=sheep,tag=!forcesheep,tag=!terraformingsheep,tag=!goldensheep,tag=!redstonesheep] at @s if entity @e[type=item,distance=..1,nbt={Item:{id:"minecraft:moss_block",tag:{Custom:terraforming_module}}}] run function upgsheep:upgrades/terraforming_module
execute as @e[type=sheep,tag=!forcesheep,tag=!terraformingsheep,tag=!goldensheep,tag=!redstonesheep] at @s if entity @e[type=item,distance=..1,nbt={Item:{id:"minecraft:gold_block",tag:{Custom:golden_module}}}] run function upgsheep:upgrades/golden_module
execute as @e[type=sheep,tag=!forcesheep,tag=!terraformingsheep,tag=!goldensheep,tag=!redstonesheep] at @s if entity @e[type=item,distance=..1,nbt={Item:{id:"minecraft:redstone_block",tag:{Custom:redstone_coil_module}}}] run function upgsheep:upgrades/redstone_coil_module


execute as @e[type=sheep,tag=terraformingsheep,nbt={Color:5b}] at @s run function upgsheep:abilities/terraforming_sheep
execute as @e[type=sheep,tag=goldensheep,nbt={Color:4b}] at @s run function upgsheep:abilities/golden_sheep

execute as @a if score @s appless >= #aa appless run function upgsheep:abilities/golden/apple
execute as @a if score @s golden_appless >= #aa appless run function upgsheep:abilities/golden/golden_apple
execute as @a if score @s ench_golden_appless >= #aa appless run function upgsheep:abilities/golden/ench_golden_apple
execute as @a if score @s golden_carrotss >= #aa appless run function upgsheep:abilities/golden/golden_carrot
execute as @a if score @s melonss >= #aa appless run function upgsheep:abilities/golden/melon